require('mocha-jshint')({
  git: {
    modified: true,
    commits: 2
  }
});
