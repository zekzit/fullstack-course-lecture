(function () {

  console.log('sanity check!');

})();
