const databaseName = 'express_tdd';
const username = 'postgres';
const password = 'ooaakk';

module.exports = {
  development: {
    client: 'postgresql',
    connection: `postgres://${username}:${password}@localhost:5432/${databaseName}`,
    migrations: {
      directory: __dirname + '/src/server/db/migrations'
    },
    seeds: {
      directory: __dirname + '/src/server/db/seeds'
    }
  },
  test: {
    client: 'postgresql',
    connection: `postgres://${username}:${password}@localhost:5432/${databaseName}_testing`,
    migrations: {
      directory: __dirname + '/src/server/db/migrations'
    },
    seeds: {
      directory: __dirname + '/src/server/db/seeds'
    }
  }
};
